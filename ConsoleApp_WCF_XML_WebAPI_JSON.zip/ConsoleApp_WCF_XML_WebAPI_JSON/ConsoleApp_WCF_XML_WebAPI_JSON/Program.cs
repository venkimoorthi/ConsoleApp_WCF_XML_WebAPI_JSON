﻿using NJsonSchema;
using System;
using System.IO;
using System.Xml.Linq;

namespace ConsoleApp_WCF_XML_WebAPI_JSON
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //schemaFromFile
            string json = File.ReadAllText("C:\\Users\\Technical Upskilling\\source\\repos\\ConsoleApp_WCF_XML_WebAPI_JSON\\ConsoleApp_WCF_XML_WebAPI_JSON\\Employee.json");
            var schemaFromFile = JsonSchema.FromSampleJson(json);
            Console.WriteLine(schemaFromFile.ToJson());           
        }
    }
}
